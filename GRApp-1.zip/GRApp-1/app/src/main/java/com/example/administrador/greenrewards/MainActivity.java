package com.example.administrador.greenrewards;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText email, contraseña;
    private int idPart;


    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //Asocia a los atributos con los elementos gráficos
        email=(EditText)findViewById(R.id.etEmailM);
        contraseña=(EditText)findViewById(R.id.etContraseñaM);


    }
    public void iniciarSesion(View v){
        try{
            //Iniciaizas la clase DatabaseHelper
            DatabaseHelper db= new DatabaseHelper(this, "GR", null, 1);
            //Permiso para leer datos
            SQLiteDatabase sq = db.getReadableDatabase();

            Cursor cursor= sq.rawQuery("select contraseña from Participante where email=" + "'" + email.getText().toString() + "';",null);
            //Si es mayor a cero es porque EL USUARIO esta DADO DE ALTA
            if(cursor.getCount()>0){
                //Esto es necesario para empezar a leer la información.
                cursor.moveToFirst();
                //VERIFICAR si la CONTRASEÑA es correcta
                //Si esto es verdadero entonces te interesa guardar en un bundle el idUsuario
                if(cursor.getString(0).equals(contraseña.getText().toString())){
                    Cursor fila = sq.rawQuery("select idUsuario from Participante where email= "+"'"+email.getText().toString()+"';",null);
                    fila.moveToFirst();
                    idPart=fila.getInt(0);

                    //Ir a otra ventana y guardar en un bundle la contraseña que acabas de recuperar
                    Intent intent = new Intent(this, MenuOpciones.class);
                    Bundle bundle= new Bundle();
                    bundle.putInt("idUsuario", idPart);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();

                }
            }
            else{
                Toast.makeText(this, "Lo sentimos, no estás registrado", Toast.LENGTH_SHORT).show();
                email.setText("");
                contraseña.setText("");
            }
        }catch (Exception ex){
            Toast.makeText(this, "" + ex, Toast.LENGTH_SHORT).show();
        }

    }

    public void btRegistrar(View v){
        Intent intent= new Intent(this, Registro.class);
        startActivity(intent);
    }



}
