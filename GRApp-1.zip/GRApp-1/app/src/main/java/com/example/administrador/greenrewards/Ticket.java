package com.example.administrador.greenrewards;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Ticket extends AppCompatActivity {
    Spinner spinner;
    Button button;
    Button button1;
    EditText numTicket;
    EditText txtMonto;


    // codigo para cargar imagen de camara y de galeria



    //Aquí termina el codigo de las imágenes
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);


        spinner = (Spinner) findViewById(R.id.spinner);
        button = (Button) findViewById(R.id.btTAS);
        button1 = (Button) findViewById(R.id.bttD);
        numTicket = (EditText) findViewById(R.id.txtTicket);
        txtMonto = (EditText) findViewById(R.id.txtMonto);

    }



    List<String> list = new ArrayList<String>();

    public void llenarCombo(View view) {

        try {
            Toast.makeText(getApplicationContext(), "Has seleccionado tiendas de autoservicio", Toast.LENGTH_SHORT).show();
            list.add("Bodega Aurrera");
            list.add("Soriana");
            list.add("City Market");
            list.add("La Comer");
            list.add("Walmart");
            list.add("Costco");
            list.add("Superama");
            list.add("Sams");
            ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, list);
            arrayAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spinner.setAdapter(arrayAdapter1);
        }
        catch(Exception ex){
            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }



    }

    public void llenarCombo2(View view) {
        try {
            list.add("Liverpool");
            list.add("Palacio de Hierro");
            list.add("Sacks fifth avenue");
            list.add("Sears");
            list.add("Suburbia");
            ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, list);
            arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spinner.setAdapter(arrayAdapter2);
        }
        catch(Exception ex){
            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }

    }



    public double SumaPuntos(double monto){

        double puntos1=0;
        try{

            if(monto<=50) {
                puntos1 = monto * .01;
            }
            else {
                if (monto <= 150) {
                    puntos1 = monto * .02;
                } else {
                    if (monto <= 300) {
                        puntos1 = monto * .03;
                    } else {
                        puntos1 = monto * .07;
                    }
                }
            }
        }
        catch(Exception ex){
            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }

        return puntos1;


    }

    public void altaTicket(View v) {

        try {
            //Recupero el id del usuario
            Bundle bundle=this.getIntent().getExtras();
            int idU= bundle.getInt("idUsuarioTick");


            //Genero los puntos que con este ticket el cliente ganó
            DatabaseHelper db = new DatabaseHelper(this, "GR", null, 1);
            Double puntos=SumaPuntos(Double.parseDouble(txtMonto.getText().toString()));

            //Insertar datos en la tabla PARTICIPANTE
            try{

                SQLiteDatabase nuevo = db.getWritableDatabase();
                ContentValues ctv = new ContentValues();
                ctv.put("numTicket", numTicket.getText().toString()); //Este es el folio del ticket que se espera que sea unico
                ctv.put("monto", txtMonto.getText().toString());
                ctv.put("puntos", puntos);
                ctv.put("idUsuario",idU);
                nuevo.insert("Ticket", null, ctv);
            }catch (Exception ex) { //Esto puede pasar por si el participante teclea un ticket con el mismo folio
                Toast.makeText(this, "Este folio ya lo ingresaste anterioremente", Toast.LENGTH_LONG).show();
            }


            Intent in= new Intent(this, GXP.class);
            startActivity(in);
            limpia(v);
            Toast.makeText(this,"Se dio de alta correctamente el ticket",Toast.LENGTH_SHORT).show();

            //Ingresar en la tabla de Participante los puntos que acaba de acumular
            SQLiteDatabase nuevo2 = db.getReadableDatabase();
            Cursor c = nuevo2.rawQuery("select puntosAcum from Participante where Participante.idUsuario= "+idU+";",null);
            c.moveToFirst();
            double puntosAcum2=c.getDouble(0);
            c.close();

            //Acumulas los puntos
            puntosAcum2=puntosAcum2+puntos;
            nuevo2.execSQL("update Participante set puntosAcum="+puntosAcum2+" where idUsuario="+idU+"");


        } catch (Exception ex) {
            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }
    }
    public  void limpia (View v){
        numTicket.setText("");
        txtMonto.setText("");
    }
    public void  baja(View v){
        DatabaseHelper admin= new DatabaseHelper(this, "GR", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String clave= numTicket.getText().toString();
        int cant= bd.delete("Ticket", "numTicket="+clave, null);

        bd.close();

        if (cant==1)
            Toast.makeText(this, "El ticket se ha dado de baja", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "No existe ese ticket", Toast.LENGTH_LONG).show();


    }






}




