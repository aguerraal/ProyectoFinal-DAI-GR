package com.example.administrador.greenrewards;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {
    EditText email, contraseña, nombre, tel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        email = (EditText) findViewById(R.id.etEmailR);
        contraseña = (EditText) findViewById(R.id.etContraseñaR);
        nombre = (EditText) findViewById(R.id.etNombreR);
        tel = (EditText) findViewById(R.id.etTelefonoR);
    }

/*
db.execSQL(" create table Participante(idUsuario integer primary key, email text,
 contraseña text, nombre text, tel text, puntosAcum integer)");
 */


    public void altaPartic(View v) {

        try{

            DatabaseHelper db= new DatabaseHelper(this, "GR",null, 1 );
            //GENERAR EL ID DEL USUARIO AUTOMÁTICO
            SQLiteDatabase sq= db.getReadableDatabase();
            Cursor cursor = sq.rawQuery("select idUsuario from Participante",null);
            int id = cursor.getCount()+1;
            cursor.close();

            //Insertar datos en la tabla PARTICIPANTE
            SQLiteDatabase nuevo=db.getWritableDatabase();
            ContentValues cv= new ContentValues();
            cv.put("idUsuario", id);
            cv.put("email", email.getText().toString());
            cv.put("contraseña", contraseña.getText().toString());
            cv.put("nombre", nombre.getText().toString());
            cv.put("tel", tel.getText().toString());
            cv.put("puntosAcum", 0);
            nuevo.insert("Participante",null, cv );

            //Intent y Bundle
            Intent intent= new Intent(this, MenuOpciones.class);
            Bundle bundle= new Bundle();
            bundle.putInt("idUsuario", id);
            intent.putExtras(bundle);
            startActivity(intent);
        }catch (Exception ex){
            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }
    }
}
/*
SQLiteDatabase bd = admin.getWritableDatabase();


        String nombre, carrera, universidad, claveUnica;
        claveUnica= cu.getText().toString();
        nombre= nom.getText().toString();
        carrera= car.getText().toString();
        universidad= uni.getText().toString();

        ContentValues registro= new ContentValues();
        registro.put("cu", claveUnica);
        registro.put("nombre", nombre);
        registro.put("carrera", carrera);
        registro.put("universidad", universidad);
        bd.insert("alumnos", null, registro);
        bd.close();
        limpia(v);
        Toast.makeText(this, "se cargaron los datos del alumno", Toast.LENGTH_LONG).show();
 */
