package com.example.administrador.greenrewards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MenuOpciones extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_opciones);





    }
    /*
    Para ir a la ventana perfil necesitas llevar el bundle que mandaste a esta ventana
    Primero recuperas el bundle, despues lo guardas en otro bundle con OTRO NOMBRE
     */
    public void btPerfil(View v){
        //Recupero el id
        Bundle bundle=this.getIntent().getExtras();
        int idUsuario= bundle.getInt("idUsuario");

        //Creo un nuevo bundle con el id recuperado
        Intent intent = new Intent(this, Perfil.class);
        Bundle bundle1= new Bundle();
        bundle1.putInt("idUsuarioPer", idUsuario);
        intent.putExtras(bundle1);
        startActivity(intent);

    }
    public void btParticipar(View v){
        //Recupero el id
        Bundle bundle=this.getIntent().getExtras();
        int idUsuario= bundle.getInt("idUsuario");

        //Creo un nuevo bundle con el id recuperado
        Intent intent = new Intent(this, Participar.class);
        Bundle bundle1= new Bundle();
        bundle1.putInt("idUsuarioPar", idUsuario);
        intent.putExtras(bundle1);
        startActivity(intent);

    }
    public void btMecanica(View v){
        Intent intent= new Intent(this, Mecanica.class);
        startActivity(intent);

    }
    public void btPremios(View v){
        Intent intent= new Intent(this, Premios.class);
        startActivity(intent);

    }
    public void btPI(View v){
        Intent intent= new Intent(this, Ticket2.class);
        startActivity(intent);

    }

    public void btSalir(View v){
        Intent intent= new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}
