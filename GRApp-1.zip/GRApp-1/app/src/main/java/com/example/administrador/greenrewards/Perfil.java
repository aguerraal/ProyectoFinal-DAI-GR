package com.example.administrador.greenrewards;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Perfil extends AppCompatActivity {
    TextView nombre, puntos;
    EditText contraseña;
    Button modifica;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        nombre =(TextView)findViewById(R.id.tvNombreP);
        puntos=(TextView)findViewById(R.id.tvPuntosAcumP);
        contraseña=(EditText)findViewById(R.id.etNewContra);
        modifica=(Button)findViewById(R.id.btCambiar);
        Bundle bundle1=this.getIntent().getExtras();
        int idUsuario1= bundle1.getInt("idUsuarioPer");


        try{

            DatabaseHelper db= new DatabaseHelper(this, "GR", null, 1);
            SQLiteDatabase leer= db.getReadableDatabase();
            //Mostrar los datos en el TextView NOMBRE
            Cursor cursor= leer.rawQuery("select nombre from Participante where idUsuario="+idUsuario1+";",null);

            if (cursor.getCount()>0){
                cursor.moveToFirst();
                nombre.setText(cursor.getString(0));
            }

            cursor.close();
            //Mostrar los puntos acumulados del Participante
            Cursor cursor2= leer.rawQuery("select puntosAcum from  Participante where Participante.idUsuario= "+idUsuario1+"",null);
            if (cursor2.getCount()>0){
                cursor2.moveToFirst();
                puntos.setText(cursor2.getString(0));
            }
            else
            {
                Toast.makeText(this, "no has dado de alta tickets", Toast.LENGTH_LONG).show();
            }


        }catch (Exception ex){
            Toast.makeText(this, ""+ex, Toast.LENGTH_LONG).show();

        }


    }
    public void modifica(View view){
        //Recuperar los datos del bundle
        Bundle bundle=this.getIntent().getExtras();
        int idUsuario2= bundle.getInt("idUsuarioPer");
        try {
            DatabaseHelper db = new DatabaseHelper(this, "GR", null, 1);
            SQLiteDatabase leer = db.getReadableDatabase();
            leer.execSQL("update Participante set contraseña='" + contraseña.getText().toString() + "' where idUsuario=" + idUsuario2 + "");
            Toast.makeText(this,"Modificó correctamente",Toast.LENGTH_SHORT).show();
        }
        catch(Exception ex){

            Toast.makeText(this, "" + ex, Toast.LENGTH_LONG).show();
        }

    }






}
