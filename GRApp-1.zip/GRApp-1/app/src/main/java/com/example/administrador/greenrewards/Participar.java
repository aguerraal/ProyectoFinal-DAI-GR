package com.example.administrador.greenrewards;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class Participar extends AppCompatActivity {

    ImageButton button;
// Jalar el id  que tares de MenuOpciones para que cuando registres un ticket puedas asignarselo
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participar);

        //Declarar variables





    }
    public void aTicket(View view){
        //Recupero el id
        Bundle bundle=this.getIntent().getExtras();
        int idUsuarioT= bundle.getInt("idUsuarioPar");

        //Creo un nuevo bundle con el id recuperado
        Intent intent1 = new Intent(this, Ticket.class);
        Bundle bundle1= new Bundle();
        bundle1.putInt("idUsuarioTick", idUsuarioT);
        intent1.putExtras(bundle1);
        startActivity(intent1);




    }






}
