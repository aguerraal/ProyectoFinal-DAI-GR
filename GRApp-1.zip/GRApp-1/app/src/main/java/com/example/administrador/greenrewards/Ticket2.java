package com.example.administrador.greenrewards;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Ticket2 extends AppCompatActivity {
    WebView webView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket2);
        webView=(WebView)findViewById(R.id.wb);
        webView.loadUrl("https://www.youtube.com/watch?v=k1vj5RbK-RA");
    }
}
