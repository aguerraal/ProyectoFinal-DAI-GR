package com.example.administrador.greenrewards;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    //RECUERDA QUE ESTOS TIENES QUE GENERARLOS
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Participante(idUsuario integer primary key, email text,  contraseña text, nombre text, tel text, puntosAcum double)");
        db.execSQL("create table Ticket(numTicket integer primary key  not null, monto integer not null, puntos double not null, idUsuario int  references Participante not null)");

    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Participante");
        db.execSQL("drop table if exists Ticket");
        //onCreate(db); Esto lo ocupas solo en el caso en que te interese que sean unicamente sus datos.
    }
}
